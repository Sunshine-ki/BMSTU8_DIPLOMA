#!/bin/sh

./utils/latexmkmod -r .latexmkmodrc "$@" -- rpz.tex
